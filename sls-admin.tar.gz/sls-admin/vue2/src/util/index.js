module.exports = {
    store: require('./store.js')
};