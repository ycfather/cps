import Form from './Form.vue';
module.exports = Form;