import Echarts from './Echarts.vue';
module.exports = Echarts;