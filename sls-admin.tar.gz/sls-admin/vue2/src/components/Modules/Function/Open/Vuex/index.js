import Vuex from './Vuex.vue';
module.exports = Vuex;