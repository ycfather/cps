module.exports = {
    Echarts: require('./Echarts/'),
    Form: require('./Form/'),
    List: require('./List/'),
    Vuex: require('./Vuex/'),
    Test404: require('./Test404/'),
};