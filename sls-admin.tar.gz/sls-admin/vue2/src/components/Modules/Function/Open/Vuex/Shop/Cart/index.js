import Cart from './Cart.vue';
module.exports = Cart;