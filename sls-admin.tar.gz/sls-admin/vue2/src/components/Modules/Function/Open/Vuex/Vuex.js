import Shop from './Shop/';
module.exports = {
    name: 'vuex',
    components: Shop,
    data() {
        return {

        }
    },
    methods: {},
    created() {},
    mounted() {}
}