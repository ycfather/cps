module.exports = {
	Function: require('./Function/'),
	Demo: require('./Demo/'),
	Adv: require('./Adv/')
};