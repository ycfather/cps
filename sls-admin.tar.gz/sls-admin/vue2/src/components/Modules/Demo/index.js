module.exports = {
    Article: require('./Article/'),
    User: require('./User/'),
    Order: require('./Order/'),
    OrderStatis: require('./OrderStatis/'),
    Commodity: require('./Commodity/')
};
