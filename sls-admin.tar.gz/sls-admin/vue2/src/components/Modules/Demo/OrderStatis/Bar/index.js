import Bar from './Bar.vue';
module.exports = Bar;