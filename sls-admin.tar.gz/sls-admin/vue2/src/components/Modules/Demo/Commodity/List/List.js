import {
  commodity as CommodityApi
} from 'config/request.js';

module.exports = {
  name: 'list',
  data() {
    return {
      commodity_list: [], //用户列表数组

      //搜索表单信息
      search_data: {
        type: 'field_cid',
        query: '',
        create_time_range: '',
        biz_id: ''
      },

      form_data: {
        promotion_time_range: ''
      },

      query_placeholder: '请输入商品ID',

      ctype_options: [{
        value: 1,
        label: '常规商品'
      }, {
        value: 2,
        label: '促销商品'
      }, {
        value: 3,
        label: '聚合页面'
      }],

      id_name_options: [{
        value: 'field_cname',
        label: '商品名称'
      }, {
        value: 'field_cid',
        label: '商品ID'
      }],

      agency_types: [{
        label: 0,
        text: '全部'
      }, {
        label: 1,
        text: '校园代理'
      }, {
        label: 2,
        text: '个人代理'
      }, {
        label: 3,
        text: '企业代理'
      }],

      rangeOptions: {
        shortcuts: [{
          text: '最近一周',
          onClick(picker) {
            const end = new Date();
            const start = new Date();
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '最近一个月',
          onClick(picker) {
            const end = new Date();
            const start = new Date();
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '最近三个月',
          onClick(picker) {
            const end = new Date();
            const start = new Date();
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
            picker.$emit('pick', [start, end]);
          }
        }]
      },

      paginations: {
        current_page: 1,
        total: 0,
        page_size: 10,
        page_sizes: [10, 20, 50, 100],
        layout: "total, sizes, prev, pager, next, jumper"
      },

      dialog: {
        show: false,
        title: '',
        commodity_info: {}
      },

      long_term_checked: false,

      fields: {
        cid: {
          info: {
            prop: 'cid',
            label: '商品ID',
            sortable: false
          },
          filter: {},
          style: {
            width: '90',
            align: 'center'
          }
        },
        cname: {
          info: {
            prop: 'cname',
            label: '商品名称',
            sortable: false
          },
          filter: {},
          style: {
            width: '220',
            align: 'center'
          }
        },
        ctype: {
          info: {
            prop: 'ctype',
            label: '类别',
            sortable: false
          },
          filter: {},
          style: {
            width: '100',
            align: 'center'
          }
        },
        agency_type: {
          info: {
            prop: 'agency_type',
            label: '代理类别',
            sortable: false
          },
          filter: {},
          style: {
            width: '100',
            align: 'center'
          }
        },
        promotion_image: {
          info: {
            prop: 'promotion_image',
            label: '推广图片',
            sortable: false
          },
          filter: {},
          style: {
            width: '120',
            align: 'center'
          }
        },
        price: {
          info: {
            prop: 'price',
            label: '单件(元)',
            sortable: false
          },
          filter: {},
          style: {
            width: '95',
            align: 'center'
          }
        },
        commission_rate: {
          info: {
            prop: 'commission_rate',
            label: '佣金比例',
            sortable: false
          },
          filter: {},
          style: {
            width: '95',
            align: 'center'
          }
        },
        status: {
          info: {
            prop: 'status',
            label: '状态',
            sortable: false
          },
          filter: {},
          style: {
            width: '120',
            align: 'center'
          }
        },
        creation_time: {
          info: {
            prop: 'creation_time',
            label: '创建时间',
            sortable: false
          },
          filter: {},
          style: {
            width: '160',
            align: 'center'
          }
        },
        promotion_time: {
          info: {
            prop: 'promotion_time',
            label: '推广周期',
            sortable: false
          },
          filter: {},
          style: {
            width: '160',
            align: 'center'
          },
          disabled: false
        },
        operation: {
          info: {
            prop: 'operation',
            label: '操作',
            sortable: false
          },
          filter: {},
          style: {
            width: '100',
            align: 'center'
          }
        },
        operator: {
          info: {
            prop: 'operator',
            label: '操作者',
            sortable: false
          },
          filter: {},
          style: {
            width: '180',
            align: 'center'
          }
        },
        biz_id: {
          info: {
            prop: 'biz_id',
            label: '业务线ID',
            sortable: false
          },
          filter: {},
          style: {
            width: '180',
            align: 'center'
          }
        },
      },

      fileList: [{
        name: 'food.jpeg',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }
  },
  methods: {
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },

    handlePreview(file) {
      console.log(file);
    },

    longTermChanged(v) {
      this.fields.promotion_time.disabled = v.target.checked
      this.dialog.commodity_info.promotion_time_type = v.target.checked ? 0 : 1
    },

    onPick(v) {
      this.dialog.commodity_info.promotion_time_range_start = parseInt(this.form_data.promotion_time_range[0] / 1000)
      this.dialog.commodity_info.promotion_time_range_end = parseInt(this.form_data.promotion_time_range[1] / 1000)
    },

    formatCtype(item) {
      var text = '未知类别'
      if (item.ctype == 1) {
        text = '常规商品'
      } else if (item.ctype == 2) {
        text = '促销商品'
      } else if (item.ctype == 3) {
        text = '聚合页面'
      }
      return text
    },

    formatAgencyType(item) {
      var text = '未知代理类别'
      switch (item.agency_type) {
        case 0:
          text = '全部'
          break
        case 1:
          text = '校园代理'
          break
        case 2:
          text = '个人代理'
          break
        case 3:
          text = '企业代理'
          break
        default :
          text = '未知代理类别'
      }

      return text
    },

    formatCommissionRate(item) {
      return item.commission_rate * 100 + "%"
    },

    formatCreationTime(item) {
      return moment(item.creation_time * 1000).format('YYYY-MM-DD HH:mm:ss')
    },

    formatPromotionTime(item) {
      var text = ''
      if (item.promotion_time_type == 0) {
        text = '长期有效'
      } else if (item.promotion_time_type == 1) {
        text = moment(item.promotion_time_range_start * 1000).format('YYYY-MM-DD')
          + ' 至 ' + moment(item.promotion_time_range_end * 1000).format('YYYY-MM-DD')
      }
      return text
    },

    formatStatus(item) {
      var text = '未知状态'
      switch (item.status) {
        case 0:
          text = '审核通过'
          break
        case 1:
          text = '待审核'
          break
        case 2:
          text = '审核不通过'
          break
        default :
          text = '未知状态'
      }

      return text
    },

    onSelect(v) {
      if (v == 'field_cid') {
        this.query_placeholder = '请输入商品ID'
      } else {
        this.query_placeholder = '请输入商品名称'
      }
    },

    /**
     * 点击搜索按钮事件
     */
    onSearch() {
      var sd = {};
      var query = this.$route.query;
      for (var p in query) {
        sd[p] = query[p];
      }

      var where = {};

      this.search_data.create_time_range_start = parseInt(this.search_data.create_time_range[0] / 1000)
      this.search_data.create_time_range_end = parseInt(this.search_data.create_time_range[1] / 1000)
      // delete this.search_data.create_time_range

      for (var s in this.search_data) {
        if (this.search_data[s]) {
          where[s] = this.search_data[s];
        } else {
          if (sd[s]) {
            delete sd[s];
          }
        }
      }

      delete where.create_time_range;

      this.getList({
        where,
        fn: () => {
          this.setPath(Object.assign(sd, where));
        }
      });
    },

    /**
     * 改变页码和当前页时需要拼装的路径方法
     * @param {string} field 参数字段名
     * @param {string} value 参数字段值
     */
    setPath(field, value) {
      var path = this.$route.path,
        query = Object.assign({}, this.$route.query);

      if (typeof field === 'object') {
        query = field;
      } else {
        query[field] = value;
      }

      this.$router.push({
        path: path,
        query: query
      });
    },


    /**
     * 改变当前页事件
     * @param  {number} page 当前页码
     */
    onChangeCurrentPage(page) {
      this.getList({
        page,
        fn: () => {
          this.setPath('page', page);
        }
      });
    },


    /**
     * 改变每页显示数量事件
     * @param  {number} size 当前每页显示数量
     */
    onChangePageSize(page_size) {
      this.getList({
        page_size,
        fn: () => {
          this.setPath('page_size', page_size);
        }
      });
    },

    onDelete(commodity, index, list) {
      if (commodity === true) {
        var id = this.batch_id;
      } else {
        var id = commodity.id;
      }

      CommodityApi.deleteCommodity.call(this, {
        id: id
      }, (data) => {
        if (commodity === true) {
          this.commodity_list = this.commodity_list.filter(function (item, idx) {
            return id.indexOf(item.id) === -1;
          });
        } else {
          list.splice(index, 1);
        }

        this.getList();
      });
    },

    onAdd() {
      this.dialog.show = true
      this.dialog.title = '创建商品'
      this.dialog.commodity_info = {agency_type: 1}
    },

    onEdit(commodity) {
      this.dialog.show = true
      this.dialog.title = '编辑商品'
      this.dialog.commodity_info = Object.assign({}, commodity)
      console.log(this.dialog.commodity_info)
      this.long_term_checked = (commodity.promotion_time_type == 0)
      this.fields.promotion_time.disabled = this.long_term_checked
      if (this.dialog.commodity_info.promotion_time_type == 1) {
        this.form_data.promotion_time_range = [new Date(this.dialog.commodity_info.promotion_time_range_start * 1000),
          new Date(this.dialog.commodity_info.promotion_time_range_end * 1000)]
      }
    },

    onSubmit() {
      console.log(this.dialog.commodity_info)
    },

    getList({
      page,
      page_size,
      where,
      fn
    } = {}) {

      var query = this.$route.query;

      this.paginations.current_page = page || parseInt(query.page) || 1;
      this.paginations.page_size = page_size || parseInt(query.page_size) || this.paginations.page_size;

      var data = {
        page: this.paginations.current_page,
        page_size: this.paginations.page_size
      };

      if (where) {
        data = Object.assign(data, where || {});
      }


      CommodityApi.selectCommodity.call(this, data, (commodity_data) => {
        this.commodity_list = commodity_data.list.data;
        this.paginations.total = commodity_data.list.total;

        fn && fn();
      });
    },
  },

  mounted() {
    this.getList({
      fn: () => {
      }
    });
  }
}
