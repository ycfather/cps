<template>
  <div class="list">
    <el-col :span="24" class='actions-top'>
      <el-form :inline="true" :model='search_data' class="demo-form-inline">
        <el-form-item>
          <el-select v-model="search_data.type" style="width:110px" @change="onSelect">
            <el-option v-for="item in id_name_options" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-input v-model="search_data.query" :placeholder="query_placeholder"></el-input>
        </el-form-item>

        <el-form-item label="创建日期">
          <el-date-picker v-model="search_data.create_time_range" type="daterange" align="right" placeholder="请选择创建日期范围"
                          :picker-options="rangeOptions">
          </el-date-picker>
        </el-form-item>

        <el-form-item label="业务线ID">
          <el-input placeholder="请输入业务线ID" v-model='search_data.biz_id'></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click='onSearch'>查询</el-button>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click='onAdd'>创建商品</el-button>
        </el-form-item>
      </el-form>
    </el-col>
    <el-table border style="width: 100%" align='center' :data="commodity_list" stripe>
      <el-table-column
        fixed
        :prop="fields.cid.info.prop"
        :label="fields.cid.info.label"
        :align="fields.cid.style.align"
        :width="fields.cid.style.width"
        :sortable="fields.cid.info.sortable"></el-table-column>
      <el-table-column
        :prop="fields.ctype.info.prop"
        :label="fields.ctype.info.label"
        :align="fields.ctype.style.align"
        :width="fields.ctype.style.width"
        :sortable="fields.ctype.info.sortable"
        :formatter="formatCtype"></el-table-column>
      <el-table-column
        :prop="fields.agency_type.info.prop"
        :label="fields.agency_type.info.label"
        :align="fields.agency_type.style.align"
        :width="fields.agency_type.style.width"
        :sortable="fields.agency_type.info.sortable"
        :formatter="formatAgencyType"></el-table-column>
      <el-table-column
        :prop="fields.cname.info.prop"
        :label="fields.cname.info.label"
        :align="fields.cname.style.align"
        :width="fields.cname.style.width"
        :sortable="fields.cname.info.sortable"></el-table-column>
      <el-table-column
        :prop="fields.promotion_image.info.prop"
        :label="fields.promotion_image.info.label"
        :align="fields.promotion_image.style.align"
        :width="fields.promotion_image.style.width"
        :sortable="fields.promotion_image.info.sortable">
        <template scope="scope">
          <img :src="scope.row.promotion_image" width="64">
        </template>
      </el-table-column>
      <el-table-column
        :prop="fields.price.info.prop"
        :label="fields.price.info.label"
        :align="fields.price.style.align"
        :width="fields.price.style.width"
        :sortable="fields.price.info.sortable"></el-table-column>
      <el-table-column
        :prop="fields.commission_rate.info.prop"
        :label="fields.commission_rate.info.label"
        :align="fields.commission_rate.style.align"
        :width="fields.commission_rate.style.width"
        :sortable="fields.commission_rate.info.sortable"
        :formatter="formatCommissionRate"></el-table-column>
      <el-table-column
        :prop="fields.creation_time.info.prop"
        :label="fields.creation_time.info.label"
        :align="fields.creation_time.style.align"
        :width="fields.creation_time.style.width"
        :sortable="fields.creation_time.info.sortable"
        :formatter="formatCreationTime"></el-table-column>
      <el-table-column
        :label="fields.promotion_time.info.label"
        :align="fields.promotion_time.style.align"
        :width="fields.promotion_time.style.width"
        :formatter="formatPromotionTime"></el-table-column>
      <el-table-column
        :prop="fields.operator.info.prop"
        :label="fields.operator.info.label"
        :align="fields.operator.style.align"
        :width="fields.operator.style.width"
        :sortable="fields.operator.info.sortable"></el-table-column>
      <el-table-column
        :prop="fields.biz_id.info.prop"
        :label="fields.biz_id.info.label"
        :align="fields.biz_id.style.align"
        :width="fields.biz_id.style.width"
        :sortable="fields.biz_id.info.sortable"></el-table-column>
      <el-table-column
        :prop="fields.status.info.prop"
        :label="fields.status.info.label"
        :align="fields.status.style.align"
        :width="fields.status.style.width"
        :sortable="fields.status.info.sortable"
        :formatter="formatStatus"></el-table-column>
      <el-table-column
        fixed="right"
        :label="fields.operation.info.label"
        :align="fields.operation.style.align"
        :width="fields.operation.style.width"
        :context="_self">
        <template scope='scope'>
          <el-button
            type="info"
            icon='edit'
            size="mini"
            @click='onEdit(scope.row)'></el-button>
          <el-button
            type="danger"
            icon='delete'
            size="mini"
            @click='onDelete(scope.row, scope.$index, commodity_list)'></el-button>
        </template>
      </el-table-column>

    </el-table>
    <el-col :span="24" class='btm-action'>
      <el-pagination
        v-if='paginations.total>0'
        class='pagination'
        :page-sizes="paginations.page_sizes"
        :page-size="paginations.page_size"
        :layout="paginations.layout"
        :total="paginations.total"
        :current-page='paginations.current_page'
        @current-change='onChangeCurrentPage'
        @size-change='onChangePageSize'>
      </el-pagination>
    </el-col>

    <el-dialog :title="dialog.title" v-model="dialog.show" size="small">
      <el-form style="margin:20px;width:60%;min-width:100%"
               label-width="120px"
               :model="dialog.commodity_info">
        <el-form-item :label="fields.cname.info.label">
          <el-input v-model="dialog.commodity_info.cname" style="width: 400px;"></el-input>
        </el-form-item>

        <el-form-item :label="fields.ctype.info.label">
          <el-select v-model="dialog.commodity_info.ctype">
            <el-option v-for="item in ctype_options" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item :label="fields.agency_type.info.label">
          <el-radio-group v-model="dialog.commodity_info.agency_type">
            <el-radio v-for="item in agency_types" :label="item.label">{{item.text}}</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item :label="fields.promotion_image.info.label">
          <el-upload
            class="upload-demo"
            action="http://jsonplaceholder.typicode.com/posts/"
            :on-preview="handlePreview"
            :on-remove="handleRemove"
            :file-list="fileList"
            list-type="picture">
            <el-button size="small" type="primary">点击上传</el-button>
            <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
          </el-upload>
        </el-form-item>

        <el-form-item :label="fields.price.info.label">
          <el-input v-model="dialog.commodity_info.price" placeholder="请输入单价" style="width: 400px;"></el-input>
        </el-form-item>

        <el-form-item :label="fields.commission_rate.info.label">
          <el-input v-model="dialog.commodity_info.commission_rate" placeholder="请输入佣金比例"
                    style="width: 400px;"></el-input>
        </el-form-item>

        <el-form-item :label="fields.promotion_time.info.label">
          <el-date-picker range-separator="~" v-model="form_data.promotion_time_range" type="daterange"
                          align="right" placeholder="请选择推广周期"
                          :disabled="fields.promotion_time.disabled" :picker-options="rangeOptions"
                          style="width: 230px;" @change="onPick">
          </el-date-picker>
          <el-checkbox v-model="long_term_checked" @change="longTermChanged">长期有效</el-checkbox>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialog.show = false">取 消</el-button>
        <el-button type="primary" @click="onSubmit">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  import ListJs from './List.js';
  module.exports = ListJs;
</script>
<style scoped lang='less'>
  .demo-form-inline {
    display: inline-block;
    float: right;
  }

  .btm-action {
    margin-top: 20px;
    text-align: center;
  }

  .actions-top {
    height: 46px;
  }

  .pagination {
    display: inline-block;
  }
</style>
