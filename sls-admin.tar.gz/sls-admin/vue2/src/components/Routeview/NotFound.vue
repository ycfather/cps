<template>
    <div class="not-found">
        没有找到页面
        <a href="#/function/open/test404">回测试404页面</a>
    </div>
</template>

<script>
    export default {
        name: 'not-found',
        data () {
            return {
                
            }
        },
        methods:{
             
        },
        created(){
        },
        mounted(){

        }
    }
</script>

<style scoped lang='less'>
    
</style>
