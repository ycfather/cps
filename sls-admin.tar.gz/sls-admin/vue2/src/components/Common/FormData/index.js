import FormData from './FormData.vue';
module.exports = FormData;