module.exports = {
    Bar: require('./Bar/'),
    Pie: require('./Pie/'),
    Line: require('./Line/')
};