import Horizontal from './Horizontal.vue';
module.exports = Horizontal;