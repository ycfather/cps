module.exports = {
    Default: require('./Default/'),
    Horizontal: require('./Horizontal/')
};