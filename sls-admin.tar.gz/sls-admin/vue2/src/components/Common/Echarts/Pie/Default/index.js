import Default from './Default.vue';
module.exports = Default;