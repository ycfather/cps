import DialogInfo from './DialogInfo.vue';
module.exports = DialogInfo;