module.exports = {
    // getCartList(state) {
    //     return state.cartList;
    // }
};