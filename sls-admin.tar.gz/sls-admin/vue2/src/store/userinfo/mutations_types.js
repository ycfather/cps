//更新用户信息
export const UPDATE_USERINFO = 'UPDATE_USERINFO';

//清空用户信息
export const REMOVE_USERINFO = 'REMOVE_USERINFO';

//更新记录密码相关信息
export const UPDATE_REMUMBER = 'UPDATE_REMUMBER';

//清空记录密码相关信息
export const REMOVE_REMUMBER = 'REMOVE_REMUMBER';