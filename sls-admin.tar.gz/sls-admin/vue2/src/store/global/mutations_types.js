//显示加载
export const SHOW_LOADING = 'SHOW_LOADING';

//关闭加载
export const HIDE_LOADING = 'HIDE_LOADING';