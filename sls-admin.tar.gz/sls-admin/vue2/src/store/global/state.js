import {
    store
} from '../../util/';


module.exports = {
    ajax_loading: false
};