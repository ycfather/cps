//展开菜单
export const SET_MENU_OPEN = 'SET_MENU_OPEN';

//关闭菜单
export const SET_MENU_CLOSE = 'SET_MENU_CLOSE';