module.exports = {
    //左侧菜单宽度
    width: '190px',
    menu_flag: true,
};